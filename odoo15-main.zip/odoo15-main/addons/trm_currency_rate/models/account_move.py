# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime
import logging

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    trm_rate = fields.Float(
        string='TRM', help="Tasa Representativa del Mercado para esta factura.")

    def fetch_trm_for_date(self, date):
        trm = self.env['res.currency.rate'].get_trm(date)
        _logger.info(f"Fetched TRM for date {date}: {trm}")
        return trm

    @api.onchange('invoice_date')
    def _onchange_invoice_date_trm(self):
        """Asigna la TRM al cambiar la fecha de la factura solo si es USD."""
        if self.invoice_date and self.currency_id.name == 'USD':
            self.trm_rate = self.fetch_trm_for_date(self.invoice_date)

    def action_post(self):
        """Sobrescribe la validación para asignar la TRM al momento de confirmar la factura solo si es USD."""
        for move in self:
            # Solo aplica si la moneda de la factura es USD
            if move.move_type == 'out_invoice' and move.currency_id.name == 'USD' and not move.trm_rate:
                _logger.info(f"Fetching TRM for USD invoice with date: {move.invoice_date}")
                trm = move.fetch_trm_for_date(move.invoice_date)
                if trm:
                    move.trm_rate = trm
                    _logger.info(f"TRM {trm} set for USD move {move.id} with date {move.invoice_date}")
                else:
                    _logger.warning(f"No TRM found for USD move {move.id} with date {move.invoice_date}")
        return super(AccountMove, self).action_post()
