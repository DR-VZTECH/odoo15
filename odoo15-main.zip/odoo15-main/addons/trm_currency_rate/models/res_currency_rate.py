# -*- coding: utf-8 -*-
import requests
from odoo import models, fields, api, _
import logging

_logger = logging.getLogger(__name__)


class ResCurrencyRate(models.Model):
    _inherit = 'res.currency.rate'

    @api.model
    def get_trm(self, date):
        # API URL para obtener los datos de TRM
        url = "https://www.datos.gov.co/resource/32sa-8pi3.json"
        params = {
            "$limit": 1,
            "$order": "vigenciadesde DESC",
            # Filtrando por la fecha específica
            "vigenciadesde": date.strftime('%Y-%m-%d')
        }

        try:
            response = requests.get(url, params=params)
            response.raise_for_status()

            data = response.json()
            if data:
                # Obtener el primer valor en la lista (más reciente para la fecha solicitada)
                trm_value = float(data[0]["valor"])
                _logger.info(f"Fetched TRM for {date}: {trm_value}")
                return trm_value
            else:
                _logger.warning(f"No TRM data found for {date}")
                return None
        except requests.exceptions.RequestException as e:
            _logger.error(f"Error fetching TRM: {str(e)}")
            return None
