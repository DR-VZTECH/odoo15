# -*- coding: utf-8 -*-
from datetime import timedelta
import requests
from odoo import models, fields, api, _
import logging

_logger = logging.getLogger(__name__)


class ResCurrency(models.Model):
    _inherit = 'res.currency'

    def update_trm_history(self, start_date_str, end_date_str):
        """Actualiza el historial de TRM para USD en rate_ids desde start_date hasta end_date."""
        # Convertir las fechas de cadena a objetos de fecha en Odoo
        start_date = fields.Date.from_string(start_date_str)
        end_date = fields.Date.from_string(end_date_str)

        url = "https://www.datos.gov.co/resource/32sa-8pi3.json"
        currency_usd = self.search([('name', '=', 'USD')], limit=1)

        if not currency_usd:
            _logger.warning("USD currency not found in res.currency")
            return

        current_date = start_date
        while current_date <= end_date:
            params = {
                "$limit": 1,
                "$order": "vigenciadesde DESC",
                "vigenciadesde": current_date.strftime('%Y-%m-%d')
            }
            try:
                response = requests.get(url, params=params)
                response.raise_for_status()

                data = response.json()
                if data:
                    trm_value = float(data[0]["valor"])
                    currency_usd.rate_ids.create({
                        'name': current_date,
                        'company_rate': 1 / trm_value,       # Este debería ser el valor inverso de la TRM
                        'inverse_company_rate': trm_value,   # Este es el valor directo de la TRM
                        'currency_id': currency_usd.id,
                    })
                    _logger.info(f"TRM for {current_date} set at {trm_value}")
                else:
                    _logger.warning(
                        f"No TRM data available for date {current_date}")
            except requests.exceptions.RequestException as e:
                _logger.error(f"Error TRM date {current_date}: {str(e)}")

            current_date += timedelta(days=1)
