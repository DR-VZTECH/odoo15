# -*- coding: utf-8 -*-
{
    'name': 'Trm_currency_rate',
    'version': '',
    'summary': """ Trm_currency_rate Summary """,
    'author': '',
    'website': '',
    'category': '',
    'depends': ['base', 'account'],
    "data": [
        "views/account_move_views.xml"
    ],
    'application': True,
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
