# -*- coding: utf-8 -*-
{
    'name': 'Deplog Contactos Email',
    'version': '0.1',
    'summary': """ Allows you to add more email fields in contacts. """,
    'author': 'DFVZ TECH SAS',
    'website': 'www.vztech.odoo.com',
    'category': 'Contacts',
    'depends': ['base', 'contacts'],
    "data": [
        "views/res_partner_views.xml"
    ],
    'application': True,
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
