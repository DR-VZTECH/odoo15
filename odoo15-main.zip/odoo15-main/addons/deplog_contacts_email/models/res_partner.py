# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError
import re


class ResPartnerInherited(models.Model):
    _inherit = 'res.partner'

    # Campos para contactos de facturación
    invoice_email_1 = fields.Char(string='Invoice Email 1')
    invoice_email_2 = fields.Char(string='Invoice Email 2')
    invoice_email_3 = fields.Char(string='Invoice Email 3')
    invoice_email_partner_id_1 = fields.Many2one(
        'res.partner', string='Invoice Partner 1')
    invoice_email_partner_id_2 = fields.Many2one(
        'res.partner', string='Invoice Partner 2')
    invoice_email_partner_id_3 = fields.Many2one(
        'res.partner', string='Invoice Partner 3')

    # Campos para contactos comerciales
    commercial_email_1 = fields.Char(string='Commercial Email 1')
    commercial_email_2 = fields.Char(string='Commercial Email 2')
    commercial_email_3 = fields.Char(string='Commercial Email 3')
    commercial_email_partner_id_1 = fields.Many2one(
        'res.partner', string='Commercial Partner 1')
    commercial_email_partner_id_2 = fields.Many2one(
        'res.partner', string='Commercial Partner 2')
    commercial_email_partner_id_3 = fields.Many2one(
        'res.partner', string='Commercial Partner 3')

    # Campos para contactos operativos
    operational_email_1 = fields.Char(string='Operational Email 1')
    operational_email_2 = fields.Char(string='Operational Email 2')
    operational_email_3 = fields.Char(string='Operational Email 3')
    operational_email_partner_id_1 = fields.Many2one(
        'res.partner', string='Operational Partner 1')
    operational_email_partner_id_2 = fields.Many2one(
        'res.partner', string='Operational Partner 2')
    operational_email_partner_id_3 = fields.Many2one(
        'res.partner', string='Operational Partner 3')

    # Campos para otros contactos
    other_email_1 = fields.Char(string='Other Email 1')
    other_email_2 = fields.Char(string='Other Email 2')
    other_email_3 = fields.Char(string='Other Email 3')
    other_email_partner_id_1 = fields.Many2one(
        'res.partner', string='Other Partner 1')
    other_email_partner_id_2 = fields.Many2one(
        'res.partner', string='Other Partner 2')
    other_email_partner_id_3 = fields.Many2one(
        'res.partner', string='Other Partner 3')

    # Método para obtener el nombre traducido del campo según el idioma del usuario
    def get_translated_field_name(self, field_name):
        field_info = self.fields_get([field_name])
        translated_name = field_info.get(field_name, {}).get('string', '')
        return translated_name

    @api.model
    def create(self, vals):
        partner = super(ResPartnerInherited, self).create(vals)

        # Manejar la creación de contactos asociados para cada categoría
        categories = [
            ('invoice_email_', 'invoice_email_partner_id_'),
            ('commercial_email_', 'commercial_email_partner_id_'),
            ('operational_email_', 'operational_email_partner_id_'),
            ('other_email_', 'other_email_partner_id_'),
        ]

        for prefix, partner_field_prefix in categories:
            for i in range(1, 4):
                email_field = f'{prefix}{i}'
                partner_field = f'{partner_field_prefix}{i}'
                if vals.get(email_field):
                    partner._create_or_update_associated_contact(
                        vals, email_field, partner_field)

        return partner

    def write(self, vals):
        # Eliminación de contactos asociados si se elimina el correo electrónico correspondiente
        categories = [
            ('invoice_email_', 'invoice_email_partner_id_'),
            ('commercial_email_', 'commercial_email_partner_id_'),
            ('operational_email_', 'operational_email_partner_id_'),
            ('other_email_', 'other_email_partner_id_'),
        ]

        for prefix, partner_field_prefix in categories:
            for i in range(1, 3):
                email_field = f'{prefix}{i}'
                partner_field = f'{partner_field_prefix}{i}'
                if email_field in vals and not vals.get(email_field):
                    associated_contact = getattr(self, partner_field)
                    if associated_contact:
                        associated_contact.unlink()

        res = super(ResPartnerInherited, self).write(vals)

        # Actualizar contactos asociados si cambian los datos principales
        if 'name' in vals or 'phone' in vals or 'mobile' in vals:
            for prefix, partner_field_prefix in categories:
                for i in range(1, 4):
                    associated_contact = getattr(
                        self, f'{partner_field_prefix}{i}')
                    if associated_contact:
                        associated_contact.write({
                            'name': self.name,
                            'phone': self.phone,
                            'mobile': self.mobile,
                        })

        # Crear o actualizar los contactos asociados después de la escritura
        for prefix, partner_field_prefix in categories:
            for i in range(1, 4):
                email_field = f'{prefix}{i}'
                partner_field = f'{partner_field_prefix}{i}'
                if email_field in vals and vals.get(email_field):
                    self._create_or_update_associated_contact(
                        vals, email_field, partner_field)

        return res

    def _create_or_update_associated_contact(self, vals, email_field, contact_field):
        if not vals.get(email_field):
            return

        associated_contact = getattr(self, contact_field)
        if associated_contact:
            associated_contact.write({
                'email': vals.get(email_field),
                'phone': self.phone,
                'mobile': self.mobile,
                'street': self.street,
                'city': self.city,
            })
        else:
            translated_field_name = self.get_translated_field_name(email_field)
            new_partner_vals = {
                'name': f'{translated_field_name}: {self.name}',
                'email': vals.get(email_field),
                'phone': self.phone,
                'mobile': self.mobile,
                'street': self.street,
                'city': self.city,
                'parent_id': self.id
            }
            associated_contact = self.env['res.partner'].create(
                new_partner_vals)
            setattr(self, contact_field, associated_contact.id)

    @api.constrains('email', 'invoice_email_1', 'invoice_email_2', 'invoice_email_3',
                    'commercial_email_1', 'commercial_email_2', 'commercial_email_3',
                    'operational_email_1', 'operational_email_2', 'operational_email_3',
                    'other_email_1', 'other_email_2', 'other_email_3')
    def _check_single_email(self):
        # Expresión regular para validar un único correo electrónico
        email_regex = r'^[\w\.-]+@[\w\.-]+\.\w{2,}$'
        for record in self:
            email_fields = {
                'email': record.email,
                'invoice_email_1': record.invoice_email_1,
                'invoice_email_2': record.invoice_email_2,
                'invoice_email_3': record.invoice_email_3,
                'commercial_email_1': record.commercial_email_1,
                'commercial_email_2': record.commercial_email_2,
                'commercial_email_3': record.commercial_email_3,
                'operational_email_1': record.operational_email_1,
                'operational_email_2': record.operational_email_2,
                'operational_email_3': record.operational_email_3,
                'other_email_1': record.other_email_1,
                'other_email_2': record.other_email_2,
                'other_email_3': record.other_email_3,
            }

            for field_name, email in email_fields.items():
                if email and not re.match(email_regex, email.strip()):
                    translated_field_name = self.get_translated_field_name(
                        field_name)
                    raise ValidationError(
                        f"El campo '{translated_field_name}' debe contener solo una dirección de correo electrónico válida.")
