from odoo import models, fields, api
from odoo.exceptions import ValidationError


class TaskEmailRecipientWizard(models.TransientModel):
    _name = 'task.email.recipient.wizard'
    _description = 'Select Recipients for Task Email'

    task_id = fields.Many2one('project.task', string='Task', required=True)
    template_id = fields.Many2one(
        'mail.template', string='Template', required=True)
    recipient_ids = fields.Many2many('res.partner', string='Recipients')

    @api.model
    def default_get(self, fields):
        """Obtiene los contactos predeterminados basados en partner_field y email_areas de la plantilla"""
        res = super(TaskEmailRecipientWizard, self).default_get(fields)
        task = self.env['project.task'].browse(self._context.get('active_id'))
        # Obteniendo la plantilla asociada a la etapa (o configurarla en task)
        template = task.stage_id.template_id

        if template and template.partner_field and template.email_areas:
            # Obtener contactos según partner_field y email_areas
            selected_contacts = set()
            for field in template.partner_field:
                partner = getattr(task, field.name, False)
                if partner:
                    contacts = self.env['res.partner.email'].search([
                        ('partner_id', '=', partner.id),
                        ('area', 'in', template.email_areas.ids)
                    ]).mapped('contact_partner_id')
                    selected_contacts.update(contacts)
            res['recipient_ids'] = [
                (6, 0, [contact.id for contact in selected_contacts if contact.email])]
        return res

    def confirm_recipients_and_send_email(self):
        """Confirma los destinatarios y envía el correo usando la plantilla"""
        for recipient in self.recipient_ids:
            self.template_id.send_mail(self.task_id.id, email_values={
                                       'partner_ids': [(6, 0, self.recipient_ids.ids)]})
