# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError


class MailTemplate(models.Model):
    _inherit = 'mail.template'

    partner_fields = fields.Many2many(
        'ir.model.fields',
        string='Partner Fields',
        domain="[('model_id', '=', model_id), ('ttype', '=', 'many2one'), ('relation', '=', 'res.partner')]",
    )

    email_areas = fields.Many2many(
        'res.partner.email.area', string='Email Areas',
    )

    def generate_email(self, res_ids, fields):
        """Sobrescribe generate_email para ajustar 'partner_ids' solo si partner_fields y email_areas están configurados."""
        result = super(MailTemplate, self).generate_email(res_ids, fields)

        for res_id in res_ids:
            if self.partner_fields and self.email_areas:
                # Obtener el registro específico según el modelo especificado en model_id
                record = self.env[self.model].browse(res_id)

                # Variable para almacenar todos los contactos encontrados
                all_valid_contacts = set()

                # Iterar sobre cada campo seleccionado en partner_fields
                for field in self.partner_fields:
                    # Obtener el contacto principal relacionado a través del campo actual
                    partner = getattr(record, field.name, False)

                    if partner:
                        # Buscar contactos relacionados en res.partner.email que coincidan en área
                        related_contacts = self.env['res.partner.email'].search([
                            ('partner_id', '=', partner.id),
                            ('area', 'in', self.email_areas.ids)
                        ]).mapped('contact_partner_id')

                        # Filtrar solo los contactos con correos válidos
                        valid_contacts = {
                            contact.id for contact in related_contacts if contact.email}

                        # Añadir los contactos válidos a la lista total
                        all_valid_contacts.update(valid_contacts)

                # Asignar los contactos encontrados al campo partner_ids
                if all_valid_contacts:
                    result[res_id]['partner_ids'] = [
                        (6, 0, list(all_valid_contacts))]

        return result
