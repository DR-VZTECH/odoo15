# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError
import re


class ResPartnerEmail(models.Model):
    _name = 'res.partner.email'
    _description = 'Partner Email'

    email = fields.Char(string='Email', required=True)
    area = fields.Many2one('res.partner.email.area',
                           string='Area', required=False)
    partner_id = fields.Many2one(
        'res.partner', string='Related Partner', required=True, ondelete='cascade')
    contact_partner_id = fields.Many2one(
        'res.partner', string='Contact Partner', readonly=True)

    # Al crear o actualizar, genera o actualiza el contacto asociado
    @api.model
    def create(self, vals):
        res = super(ResPartnerEmail, self).create(vals)
        if res.email:
            res._create_associated_contact()
        return res

    def write(self, vals):
        res = super(ResPartnerEmail, self).write(vals)
        if 'email' in vals:
            self._create_associated_contact()
        return res

    # Método para eliminar el contacto asociado cuando se elimina el correo
    def unlink(self):
        for record in self:
            if record.contact_partner_id:
                record.contact_partner_id.unlink()
        return super(ResPartnerEmail, self).unlink()

    # Método para crear o actualizar el contacto asociado
    def _create_associated_contact(self):
        # Formatear el nombre del contacto como "email area - partner_id.name"
        contact_name = f"{self.area.name if self.area else ''} - {self.email} - {self.partner_id.name}"

        contact_vals = {
            'name': contact_name,
            'email': self.email,
            'phone': self.partner_id.phone,
            'mobile': self.partner_id.mobile,
            'street': self.partner_id.street,
            'city': self.partner_id.city,
            'parent_id': self.partner_id.id
        }

        if self.contact_partner_id:
            self.contact_partner_id.write(contact_vals)
        else:
            self.contact_partner_id = self.env['res.partner'].create(
                contact_vals)

    # Validación del área y formato de email
    @api.constrains('email', 'area')
    def _check_email_and_area(self):
        """Ensure area is provided if email is set, and validate single email format."""
        email_regex = r'^[\w\.-]+@[\w\.-]+\.\w{2,}$'
        for record in self:
            if record.email and (',' in record.email or ';' in record.email):
                raise ValidationError(
                    "El campo 'Correo' en Correos Electrónicos, solo puede contener una dirección de correo electrónico.")
            if record.email and not re.match(email_regex, record.email.strip()):
                raise ValidationError(
                    "El campo 'Correo' en Correos Electrónicos, debe contener una dirección de correo electrónico válida.")
            if record.email and not record.area:
                raise ValidationError(
                    f"El campo 'Categorías' es requerido cuando agrega un 'Correo' en Correos Electrónicos")
