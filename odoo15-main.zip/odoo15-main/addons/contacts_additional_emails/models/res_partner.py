# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError
import re


class ResPartnerInherited(models.Model):
    _inherit = 'res.partner'

    partner_emails = fields.One2many(
        'res.partner.email', 'partner_id', string='Emails')

    @api.constrains('email')
    def _check_single_email_format(self):
        """Restrict the email field to only allow a single email address."""
        for record in self:
            if record.email and (',' in record.email or ';' in record.email):
                raise ValidationError(
                    "El campo 'Correo electrónico' solo puede contener una dirección de correo electrónico.")
            # Validar formato correcto del correo
            email_regex = r'^[\w\.-]+@[\w\.-]+\.\w{2,}$'
            if not re.match(email_regex, record.email.strip()):
                raise ValidationError(
                    "El campo 'Correo electrónico' debe contener una dirección de correo electrónico válida.")
