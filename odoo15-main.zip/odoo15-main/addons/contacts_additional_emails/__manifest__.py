# -*- coding: utf-8 -*-
{
    'name': 'Correos Electrónicos Adicionales - Contactos',
    'version': '0.1',
    'summary': """ Allows you to add more email fields in contacts. """,
    'author': 'DFVZ TECH SAS',
    'website': 'www.vztech.odoo.com',
    'category': 'Contacts',
    'depends': [
        'base',
        'contacts',
        'mail',
        'project',
    ],
    "data": [
        "views/res_partner_views.xml",
        "security/ir.model.access.csv",
        "views/res_partner_email_area_views.xml",
        "views/mail_template_views.xml",
        "wizard/task_email_recipient_wizard.xml"
    ],
    'application': False,
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
